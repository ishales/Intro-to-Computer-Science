//
//  badvector.cpp
//  hw4 1d
//
//  Created by Isabelle Hales on 3/6/23.
//  Copyright © 2023 CS32. All rights reserved.
//

void removeBad(vector<Movie*>& v)
{
    vector<Movie*>::iterator want = v.begin();
    while(want != v.end()){
        Movie* temp = *want;
        if(temp->rating() < 50){
            delete temp;
            want = v.erase(want);
        } else {
            want++;
        }
    }
}

