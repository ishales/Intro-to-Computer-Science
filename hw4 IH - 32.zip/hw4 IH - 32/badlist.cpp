//  badlist.cpp
//  hw4 1c
//
//  Created by Isabelle Hales on 3/6/23.
//  Copyright © 2023 CS32. All rights reserved.
//

void removeBad(list<Movie*>& li)
{
    list<Movie*>::iterator my = li.begin();
    while(my != li.end()){
        Movie* temp = *my;
        if(temp->rating() < 50){
            delete temp;
            my = li.erase(my);
        } else {
            my++;
        }
    }
    
}

