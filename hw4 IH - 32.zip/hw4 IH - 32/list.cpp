//
//  main.cpp
//  hw4 4
//
//  Created by Isabelle Hales on 3/7/23.
//  Copyright © 2023 CS32. All rights reserved.
//

void listAll(string path, const File* f)  // two-parameter overload
{
    const vector<File*>* myFiles = f->files();
    if(f->files() == nullptr){
        cout << path << endl;
        return;
    } else {
        cout << path + "/" << endl;
        if(myFiles == nullptr){
            return;
        } else {
            for(int i = 0; i < myFiles->size(); i++){
                File* temp = (*myFiles)[i];
                listAll(path + "/" + temp->name(), temp);
            }
        }
    }
    
}

