//
//  Actor.cpp
//  p3
//
//  Created by Isabelle Hales on 2/23/23.
//  Copyright © 2023 CS32. All rights reserved.
//

#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

StudentWorld* Actor::Gworld() const {
    return myWorld;
}

//get random dice roll
int Player::DiceRoll() {
    int DiceMove;
    DiceMove = 1 + (rand() % 10);
    return DiceMove;
}

//get walk direction
int Player::getWalkD(){
    return moveDir;
}


//access ticks_to_move
int Player::Ticks2Move() const {
    return ticks_to_move;
}

//access player stars
int Player::checkStars() const {
    return p_stars;
}

//access to waiting state
bool Player::getState() const {
    return waitingState;
}

//changes waiting state
void Player::changeState(bool change) {
    waitingState = change;
}

//change star value
void Player::changeStars(int amt){
    p_stars += amt;
    landed = false;
}

//check coin num
int Player::checkCoins() const{
    return p_coins;
}

//adds/subtracts coins to player
void Player::changeCoins(int amt){
    p_coins += amt;
    landed = false;
}

//baddie can act on player
void Player::changeBadCan(bool change){
    badCan = change;
}

//check if baddie can act
bool Player::canBad(){
    return badCan;
}

//changes walking direction of player
void Player::changeDirection(int wD){
    moveDir = wD;
}

//checks if player is new or not (true is new, false is not new)
bool Player::landedP() {
    //check if they've landed (not moving)
    if(landed == true){
        return true;
    }
    return false;
}

//changes value of ticks_to_move
void Player::changeTicks(int tix){
    ticks_to_move += tix;
}

//set player coin amount
void Player::setCoins(int amt){
    p_coins = amt;
}

//set player star amount
void Player::setStars(int amt){
    p_stars = amt;
}

void Player::changeValDir(bool val) {
    validDir = val;
}

//teleport player
void Player::teleport() {
//pick a valid board square
    int rx;
    int ry;
    bool spot = false;
    while(spot == false){
        rx = (randInt(0, 15)) * 16;
        ry = (randInt(0, 15)) * 16;
        //check valid square
        Actor* check = Gworld()->getSquare(rx, ry);
        if(check != nullptr){
            spot = true;
        }
    }
//update avatars location to that square
    moveTo(rx, ry);
//set player's direction to invalid
    changeValDir(false);
    return;
}

//does player have vortex
bool Player::hasVortex() {
    if(vortex == true){
        return true;
    }
    return false;
}

//change whether player has vortex or not
void Player::changeVortex(bool Vchange) {
    vortex = Vchange;
}

//corrects invalid direction
void Player::fixInvalid(bool checkRight, bool checkLeft, bool checkUp, bool checkDown){
    int dir = getWalkD();
    
    //can't right or left (same behavior)
    if((dir == 0 && checkRight == false) || (dir == 180 && checkLeft == false)){
        if(checkUp == true && checkDown == true){
            changeDirection(90);
            return;
        } else if(checkUp == true){
            changeDirection(90);
            return;
        } else if(checkDown == true){
            changeDirection(270);
            return;
        }
    } else if ((dir == 90 && checkUp == false) || (dir == 270 && checkDown == false)) {
        if(checkRight == true && checkLeft == true){
            changeDirection(0);
            return;
        } else if(checkRight == true){
            changeDirection(0);
            return;
        } else if(checkLeft == true){
            changeDirection(180);
            setDirection(180);
            return;
        }
    }
}

//count possible moves
int Player::countMoves(bool checkRight, bool checkLeft, bool checkUp, bool checkDown){
    int count = 0;
    if(checkRight == true){
        count++;
    } if(checkLeft == true){
        count++;
    } if(checkUp == true){
        count++;
    } if(checkDown == true){
        count++;
    }
    return count;
}


//do something function for base Player
void Player::doSomething() {
    Board myB = Gworld()->getBoard();
    int px = getX() / SPRITE_WIDTH;
    int py = getY() / SPRITE_WIDTH;
    
    int pD = getWalkD();
    bool checkRight = (myB.getContentsOf(px+1, py) != Board::empty); //true if can right
    bool checkLeft = (myB.getContentsOf(px-1, py) != Board::empty); //true if can left
    bool checkDown = (myB.getContentsOf(px, py-1) != Board::empty); //true if can down
    bool checkUp = (myB.getContentsOf(px, py+1) != Board::empty); //true if can up
    
    //player is in waiting state
    if(waitingState == true){
        landed = false;
        //reset val dir after teleporting
        if(validDir == false){
            fixInvalid(checkRight, checkLeft, checkUp, checkDown);
            validDir = true;
        }
        //get player action
        int Waction = Gworld()->getAction(Pnum);
        //player wants to roll
        if(Waction == ACTION_ROLL){
            int die_Roll = DiceRoll();
            ticks_to_move = die_Roll * 8;
            waitingState = false;
        
        } //player wants to fire
        else if(Waction == ACTION_FIRE){
            //vortex code
            if(hasVortex() == true) {
                //Introduce a new Vortex projectile on the square directly in front of the Avatar in the Avatar's current walk direction.
                int wd = getWalkD();
                if(wd == right){
                    Gworld()->addVortex(getX()+2, getY(), wd);
                } else if(wd == left){
                    Gworld()->addVortex(getX()-2, getY(), wd);
                } else if(wd == up) {
                    Gworld()->addVortex(getX(), getY()+2, wd);
                } else if(wd == down) {
                    Gworld()->addVortex(getX(), getY()-2, wd);
                }
                Gworld()->playSound(SOUND_PLAYER_FIRE);
                vortex = false;
            }
        } //user didn't press valid key
        else {
            return;
        }
        
    } //player end of waiting state
    //player in WALKING state
    if (waitingState == false){
    pD = getWalkD();
        
    if((getX() % 16) == 0 && (getY() % 16) == 0) {
        pD = getWalkD();
        int px = getX() / SPRITE_WIDTH;
        int py = getY() / SPRITE_WIDTH;
        checkRight = (myB.getContentsOf(px+1, py) != Board::empty); //true if can right
        checkLeft = (myB.getContentsOf(px-1, py) != Board::empty); //true if can left
        checkDown = (myB.getContentsOf(px, py-1) != Board::empty); //true if can down
        checkUp = (myB.getContentsOf(px, py+1) != Board::empty); //true if can up
        int check = 0;
        check = countMoves(checkRight, checkLeft, checkUp, checkDown);
        
        //if player at directional square
        if(myB.getContentsOf(px, py) == Board::right_dir_square || myB.getContentsOf(px, py) == Board::left_dir_square || myB.getContentsOf(px, py) == Board::up_dir_square || myB.getContentsOf(px, py) == Board::down_dir_square){
            if(myB.getContentsOf(px, py) == Board::right_dir_square){
                changeDirection(right);
            } else if (myB.getContentsOf(px, py) == Board::left_dir_square){
                changeDirection(left);
                setDirection(180);
            } else if (myB.getContentsOf(px, py) == Board::up_dir_square) {
                changeDirection(up);
            } else if (myB.getContentsOf(px, py) == Board::down_dir_square) {
                changeDirection(down);
            }
        }
        //player at fork
        else if (check > 2) {
            //at fork
            int ask = Gworld()->getAction(Pnum);
            if(ask == ACTION_UP && checkUp == true && pD != down){
                changeDirection(up);
            } else if(ask == ACTION_DOWN && checkDown == true && pD != up){
                changeDirection(down);
            } else if(ask == ACTION_RIGHT && checkRight == true && pD != left){
                changeDirection(right);
            } else if(ask == ACTION_LEFT && checkLeft == true && pD != right){
                changeDirection(left);
                setDirection(180);
            } else {
                return;
            }
        }
        //if player can't move forward in direction
        else{
            fixInvalid(checkRight, checkLeft, checkUp, checkDown);
            }
    }
    //update walk direction & set direction
    pD = getWalkD();
    if(pD == left){
        setDirection(180);
    } else {
        setDirection(0);
    }
        
    //step d
    moveAtAngle(pD, 2);
    ticks_to_move--;
    if(ticks_to_move == 0){
        waitingState = true;
        landed = true;
    }
    }
    return;
}


//do something for base square class
void Square::doSomething() {
    return;
}


//do something for COIN square class
void COINSquare::doSomething() {
    //If coin is not active, the Coin Square must do nothing and immediately return.
    if(!CSqAlive){
        return;
    }
    //grab player pointers
    Player* currPe = Gworld()->getPeach();
    Player* currYo = Gworld()->getYoshi();
    
    int sqX = getX();
    int sqY = getY();
    
    //if the player is a "new" peach player
    if(currPe->landedP()){
        //check that player is on square
        if(currPe->getX() == sqX && currPe->getY() == sqY){
            //coin square is blue
            if(sqType == 1){
                //give the player 3 coins
                currPe->changeCoins(3);
                Gworld()->playSound(SOUND_GIVE_COIN);
            }
            //coin square is red
            else if(sqType == 2){
                //take away 3 coins if possible
                if(currPe->checkCoins() >= 3){
                    currPe->changeCoins(-3);
                    Gworld()->playSound(SOUND_TAKE_COIN);
                }
                //is player has less than 3 coins, take away remaining coins
                else if(currPe->checkCoins() > 0){
                    currPe->changeCoins(currPe->checkCoins());
                    Gworld()->playSound(SOUND_TAKE_COIN);
                }
            }
        }
    }
    
    //if the player is a "new" yoshi player
    if(currYo->landedP()){
        //check that player is on square
        if(currYo->getX() == sqX && currYo->getY() == sqY){
            //coin square is blue
            if(sqType == 1){
                //give the player 3 coins
                currYo->changeCoins(3);
                Gworld()->playSound(SOUND_GIVE_COIN);
            }
            //coin square is red
            else if(sqType == 2){
                //take away 3 coins if possible
                if(currYo->checkCoins() >= 3){
                    currYo->changeCoins(-3);
                    Gworld()->playSound(SOUND_TAKE_COIN);
                }
                //is player has less than 3 coins, take away remaining coins
                else if(currYo->checkCoins() > 0){
                    currYo->changeCoins(currPe->checkCoins());
                    Gworld()->playSound(SOUND_TAKE_COIN);
                }
            }
        }
    }
    

    
    return;
}

//event do something
void EventS::doSomething() {
    //get player pointers
       Player* currPe = Gworld()->getPeach();
       Player* currYo = Gworld()->getYoshi();
       
       int sqX = getX();
       int sqY = getY();
    
    //if PEACH has landed
    if(currPe->landedP()){
        if(currPe->getX() == sqX && currPe->getY() == sqY){
            int option = randInt(1,3);
            switch(option){
                case 1: { //teleport player
                    currPe->teleport();
                    Gworld()->playSound(SOUND_PLAYER_TELEPORT);
                    break;
                }
                case 2: { //swap players
                    Gworld()->playSound(SOUND_PLAYER_TELEPORT);
                    //swap x,y coord
                    int tX = currPe->getX();
                    int tY = currPe->getY();
                    currPe->moveTo(currYo->getX(), currYo->getY());
                    currYo->moveTo(tX, tY);
                    //swap number of ticks
                    int tempTick = currPe->Ticks2Move();
                    currPe->changeTicks(currYo->Ticks2Move());
                    currYo->changeTicks(tempTick);
                    //swap walk dir
                    int tWd = currPe->getWalkD();
                    currPe->changeDirection(currYo->getWalkD());
                    currYo->changeDirection(tWd);
                    //swap sprite dir
                    int tSd = currPe->getDirection();
                    currPe->setDirection(currYo->getDirection());
                    currYo->setDirection(tSd);
                    //swap roll/walk state
                    bool tState = currPe->getState();
                    currPe->changeState(currYo->getState());
                    currYo->changeState(tState);
                    break;
                }
                case 3: { //give player a vortex (if don't have one)
                    if(currPe->hasVortex() == true){
                        return;
                    } else {
                        currPe->changeVortex(true);
                        Gworld()->playSound(SOUND_GIVE_VORTEX);
                    }
                    break;
                }
            }
        }
    }
   
    //NOTE: After the players have been swapped, the Event Square must NOT activate on the other player who just had its position swapped onto the Event Square.
    
    //if YOSHI has landed
    else if(currYo->landedP()){
        if(currYo->getX() == sqX && currYo->getY() == sqY){
            int option = randInt(1,3);
            switch(option){
                case 1: { //teleport player
                    currYo->teleport();
                    Gworld()->playSound(SOUND_PLAYER_TELEPORT);
                    break;
                }
                case 2: { //swap players
                    Gworld()->playSound(SOUND_PLAYER_TELEPORT);
                    //swap x,y coord
                    int tX = currPe->getX();
                    int tY = currPe->getY();
                    currPe->moveTo(currYo->getX(), currYo->getY());
                    currYo->moveTo(tX, tY);
                    //swap number of ticks
                    int tempTick = currPe->Ticks2Move();
                    currPe->changeTicks(currYo->Ticks2Move());
                    currYo->changeTicks(tempTick);
                    //swap walk dir
                    int tWd = currPe->getWalkD();
                    currPe->changeDirection(currYo->getWalkD());
                    currYo->changeDirection(tWd);
                    //swap sprite dir
                    int tSd = currPe->getDirection();
                    currPe->setDirection(currYo->getDirection());
                    currYo->setDirection(tSd);
                    //swap roll/walk state
                    bool tState = currPe->getState();
                    currPe->changeState(currYo->getState());
                    currYo->changeState(tState);
                    break;
                }
                case 3: { //give player a vortex (if don't have one)
                    if(currYo->hasVortex() == true){
                        return;
                    } else {
                        currYo->changeVortex(true);
                        Gworld()->playSound(SOUND_GIVE_VORTEX);
                    }
                    break;
                }
            }
        }
    }
    return;
}

//star do something
void StarS::doSomething() {
    //get player pointer
    Player* currPe = Gworld()->getPeach();
    Player* currYo = Gworld()->getYoshi();
    
    int sqX = getX();
    int sqY = getY();
    
// If a new PEACH player has landed on or moved onto the square then:
   if(currPe->landedP()){
       if(currPe->getX() == sqX && currPe->getY() == sqY){
        //If the player has fewer than 20 coins, immediately return
        if(currPe->checkCoins() < 20){
            return;
        } else {
            //take away 20 coins from player
            currPe->changeCoins(-20);
            //give 1 star to player
            currPe->changeStars(1);
            //play sound
            Gworld()->playSound(SOUND_GIVE_STAR);
            }
       }
   }
    
// If a new YOSHI player has landed on or moved onto the square then:
    if(currYo->landedP()){
        if(currYo->getX() == sqX && currYo->getY() == sqY){
         //If the player has fewer than 20 coins, immediately return
         if(currYo->checkCoins() < 20){
             return;
         } else {
             //take away 20 coins from player
             currYo->changeCoins(-20);
             //give 1 star to player
             currYo->changeStars(1);
             //play sound
             Gworld()->playSound(SOUND_GIVE_STAR);
             }
        }
    }
    return;
}

//do something for dir square
void DIRSquare::doSomething() {
    //interaction handled by player
    return;
}

//do something for bank square
void BankS::doSomething() {
    //get player pointer
    Player* currPe = Gworld()->getPeach();
    Player* currYo = Gworld()->getYoshi();
    
    int sqX = getX();
    int sqY = getY();
    
    //if a new PEACH player has landed upon the square
    if(currPe->landedP()) {
        if(currPe->getX() == sqX && currPe->getY() == sqY){
        //get the balance of the bank and give that many coins to the player
        int currBank = Gworld()->getBankBalance();
        currPe->changeCoins(currBank);
        //set the balance of the bank to zero
        Gworld()->changeCentralBank(-currBank);
        //play the SOUND_WITHDRAW_BANK sound using playSound()
        Gworld()->playSound(SOUND_WITHDRAW_BANK);
        }
    }
    
    //if a PEACH player has moved onto the square (but not landed on it).
    else if(currPe->landedP() == false) {
        if(currPe->getX() == sqX && currPe->getY() == sqY){
        //deduct 5 coins from the player (or as many as the player has)
        //add to the central bank account as many coins as were deducted from the player
        int value = currPe->checkCoins();
        //if player has less than 5 coins
        if(value < 5){
            currPe->changeCoins(-value);
            Gworld()->changeCentralBank(value);
        } else {
           currPe->changeCoins(-5);
           Gworld()->changeCentralBank(5);
        }
        //play the SOUND_DEPOSIT_BANK sound using playSound()
        Gworld()->playSound(SOUND_DEPOSIT_BANK);
        }
    }
    
    //if a new YOSHI player has landed upon the square
    if(currYo->landedP()) {
        if(currYo->getX() == sqX && currYo->getY() == sqY){
        //get the balance of the bank and give that many coins to the player
        int currBank = Gworld()->getBankBalance();
        currYo->changeCoins(currBank);
        //set the balance of the bank to zero
        Gworld()->changeCentralBank(-currBank);
        //play the SOUND_WITHDRAW_BANK sound using playSound()
        Gworld()->playSound(SOUND_WITHDRAW_BANK);
        }
    }
    
    //if a YOSHI player has moved onto the square (but not landed on it).
    else if(currYo->landedP() == false) {
        if(currYo->getX() == sqX && currYo->getY() == sqY){
        //deduct 5 coins from the player (or as many as the player has)
        //add to the central bank account as many coins as were deducted from the player
        int value = currYo->checkCoins();
        //if player has less than 5 coins
        if(value < 5){
            currYo->changeCoins(-value);
            Gworld()->changeCentralBank(value);
        } else {
           currYo->changeCoins(-5);
           Gworld()->changeCentralBank(5);
        }
        //play the SOUND_DEPOSIT_BANK sound using playSound()
        Gworld()->playSound(SOUND_DEPOSIT_BANK);
        }
    }
    
    return;
}

//do something for dropping square
void DropS::doSomething() {
    //get player pointer
    Player* currPe = Gworld()->getPeach();
    Player* currYo = Gworld()->getYoshi();
    
    int sqX = getX();
    int sqY = getY();
    
    //if new PEACH player
    if(currPe->landedP()){
        if(currPe->getX() == sqX && currPe->getY() == sqY){
        //pick one of the following actions and execute it:
        int option = randInt(1, 2);
        int coinAmt = currPe->checkCoins();
        int stars = currPe->checkStars();
        switch(option) {
            case 1:
                //option #1: deduct 10 coins from the player (or as many as the player has, if fewer than 10; a player can never have negative coins)
                if(coinAmt < 10) {
                    currPe->changeCoins(-coinAmt);
                } else {
                    currPe->changeCoins(-10);
                }
                break;
            case 2:
                //option #2: deduct one star from the player if the player has at least one star
                if (stars >= 1) {
                    currPe->changeStars(-1);
                }
                break;
        }
        //play the SOUND_DROPPING_SQUARE_ACTIVATE sound using playSound()
        Gworld()->playSound(SOUND_DROPPING_SQUARE_ACTIVATE);
        }
    }
    
    
    //if new YOSHI player
     if(currYo->landedP()){
         if(currYo->getX() == sqX && currYo->getY() == sqY){
         //pick one of the following actions and execute it:
         int option = randInt(1, 2);
         int coinAmt = currYo->checkCoins();
         int stars = currYo->checkStars();
         switch(option) {
             case 1:
                 //option #1: deduct 10 coins from the player (or as many as the player has, if fewer than 10; a player can never have negative coins)
                 if(coinAmt < 10) {
                     currYo->changeCoins(-coinAmt);
                 } else {
                     currYo->changeCoins(-10);
                 }
                 break;
             case 2:
                 //option #2: deduct one star from the player if the player has at least one star
                 if (stars >= 1) {
                     currYo->changeStars(-1);
                 }
                 break;
         }
         //play the SOUND_DROPPING_SQUARE_ACTIVATE sound using playSound()
         Gworld()->playSound(SOUND_DROPPING_SQUARE_ACTIVATE);
         }
     }
    
    return;
}


//diffPause Bowser
void Bowser::doDiffStuffPause(Player* play){
    //50% chance
    int choice = randInt(1,2);
    if(choice == 1){
        int lossC = play->checkCoins();
        play->changeCoins(-lossC);
        int lossS = play->checkStars();
        play->changeStars(-lossS);
        //play sound
        Gworld()->playSound(SOUND_BOWSER_ACTIVATE);
    }
    play->changeBadCan(false);
    return;
}

//diffPause Boo
void Boo::doDiffStuffPause(Player* play){
    //2 options
    int option = randInt(1, 2);
    //swap player coins
    if(option == 1){
        Gworld()->swapCoins();
    } else if (option == 2){
        Gworld()->swapStars();
    }
    play->changeBadCan(false);
    return;
}

//BOWSER squares
int Bowser::calcSquares(){
    return randInt(1, 10);
}

//BOO squares
int Boo::calcSquares(){
    return randInt(1, 3);
}

//BOWSER diff walking
void Bowser::doDiffStuffWalk(){
    int option = randInt(1, 4);
    if(option == 1){
        int bx = getX();
        int by = getY();
        //remove square
        Gworld()->deleteSquare(bx, by);
        //add dropping square
        Gworld()->addDropS(bx, by);
        //play sound
        Gworld()->playSound(SOUND_DROPPING_SQUARE_CREATED);
    }
    return;
}

//BOO diff walking
void Boo::doDiffStuffWalk(){
    return;
}


//do something for base baddie class
void Baddie::doSomething() {
    //grab players
    Player* currPe = Gworld()->getPeach();
    Player* currYo = Gworld()->getYoshi();
    Board a = Gworld()->getBoard();
    
    int bx = getX() / SPRITE_WIDTH;
    int by = getY() / SPRITE_WIDTH;
    
    //check surroundings
    bool checkRight = ((a.getContentsOf(bx+1, by)) != Board::empty); //true if can move
    bool checkLeft = ((a.getContentsOf(bx-1, by)) != Board::empty); //true if can move
    bool checkUp = ((a.getContentsOf(bx, by+1)) != Board::empty); //true if can move
    bool checkDown = ((a.getContentsOf(bx, by-1)) != Board::empty); //true if can move
    
    //baddie is paused
    if(PausedState == true){
        //if on same coord as PEACH & player in paused state
        if(bx == (currPe->getX() / SPRITE_WIDTH) && by == (currPe->getY() / SPRITE_WIDTH) && currPe->getState() == true){
            if(currPe->canBad() == true){
                doDiffStuffPause(currPe);
            }
        }
        //if on same coord as YOSHI & player in paused state
        if(bx == (currYo->getX() / SPRITE_WIDTH) && by == (currYo->getY() / SPRITE_WIDTH) && currYo->getState() == true){
            if(currYo->canBad() == true){
                doDiffStuffPause(currYo);
            }
        }
        pauseCount--;
        if(pauseCount == 0){
            int s2move = calcSquares();
            ticks_to_move = s2move * 8;
            //pick new random direction
            std::vector<int> possibleD;
            if(checkRight == true){
                possibleD.push_back(0);
            } if(checkLeft == true){
                possibleD.push_back(180);
            } if(checkUp == true){
                possibleD.push_back(90);
            } if(checkDown == true){
                possibleD.push_back(270);
            }
            int VS = possibleD.size();
            if(VS == 0){
                return;
            }
            int choser = randInt(0, VS-1);
            walkingDir = possibleD.at(choser);
            //update sprite direction
            if(walkingDir == 180){
                setDirection(180);
            } else {
                setDirection(0);
            }
            //set bowser to walking state
            PausedState = false;
        }
    }
    //baddie in walking state
    if(PausedState == false) {
        //baddie atop square and at fork
        if((getX() % 16 == 0) && (getY() % 16 == 0)){
            std::vector<int> moves;
            if(checkRight == true){
                moves.push_back(0);
            } if(checkLeft == true){
                moves.push_back(180);
            } if(checkUp == true){
                moves.push_back(90);
            } if(checkDown == true){
                moves.push_back(270);
            }
            int ms = moves.size();
            //check fork
            if(ms > 1) {
                int choser = randInt(0, ms-1);
                walkingDir = moves.at(choser);
                if(walkingDir == 180){
                    setDirection(180);
                } else {
                    setDirection(0);
                }
            } else if( (walkingDir == 0 && checkRight == false) || (walkingDir == 180 && checkLeft == false) || (walkingDir == 90 && checkUp == false) || (walkingDir == 270 && checkDown == false)) {
                //baddie can't go in forward direction
                switch(walkingDir){
                    case 0:
                    case 180:
                        if(checkUp == true){
                            walkingDir = 90;
                        } else if(checkDown == true){
                            walkingDir = 270;
                        }
                        break;
                    case 90:
                    case 270:
                        if(checkRight == true){
                            walkingDir = 0;
                        } else if(checkLeft == true){
                            walkingDir = 180;
                        }
                        break;
                }
                if(walkingDir == 180){
                    setDirection(180);
                } else {
                    setDirection(0);
                }
            }
        }
        // step c and on
        moveAtAngle(walkingDir, 2);
        ticks_to_move--;
        if(ticks_to_move == 0){
            PausedState = true;
            pauseCount = 180;
            currPe->changeBadCan(true);
            currYo->changeBadCan(true);
            doDiffStuffWalk();
        }
    }
    return;
}

//BOO do some
void Boo::doSomething(){
    Baddie::doSomething();
    return;
}

//BOWSER do some
void Bowser::doSomething(){
    Baddie::doSomething();
    return;
}

//teleport baddie
void Baddie::teleport() {
//pick a valid board square
    int rx;
    int ry;
    bool spot = false;
    while(spot == false){
        rx = (randInt(0, 15)) * 16;
        ry = (randInt(0, 15)) * 16;
        //check valid square
        Actor* check = Gworld()->getSquare(rx, ry);
        std::cerr << spot << std::endl;
        if(check != nullptr){
            spot = true;
            //update avatars location to that square
            moveTo(rx, ry);
        }
    }

    return;
}

//Baddie hit by vortex
void Baddie::hit() {
    //teleport itself
    teleport();
    //walking dir right & 0 sprite dir
    walkingDir = 0;
    setDirection(0);
    //go to paused state, set pause ticks to 180
    PausedState = true;
    pauseCount = 180;
    //get rid of vortex
    return;
}

//Vortex doSomething
void Vortex::doSomething() {
    //make sure its active
    if(active == false){
        return;
    } else {
        //move 2 pixels in direction
        moveAtAngle(firingD, 2);
        //if the Vortex object leaves the screen, it is non-active and deleted
        int vx = getX();
        int vy = getY();
        
        if(vx < 0 || vx >= VIEW_WIDTH || vy < 0 || vy >= VIEW_HEIGHT){
            active = false;
            Gworld()->destroyVortex(this);
        } else {
            vx = vx / SPRITE_WIDTH;
            vy = vy / SPRITE_HEIGHT;
            // vortex checks if it currently overlaps with an object that can be impacted
            Actor* grabbed = Gworld()->getSquare(vx, vy);
            if(grabbed != nullptr) {
                if(grabbed->canBeHit() == true){
                //inform the other object that it has been impacted
                grabbed->hit();
                //vortex becomes inactive
                active = false;
                //play vortex sound
                Gworld()->playSound(SOUND_HIT_BY_VORTEX);
                Gworld()->destroyVortex(this);
                }
            }
        }
    }
}

