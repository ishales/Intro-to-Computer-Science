//
//  Actor.h
//  p3
//
//  Created by Isabelle Hales on 2/23/23.
//  Copyright © 2023 CS32. All rights reserved.
//

#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include "StudentWorld.h"

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

//base class for every game actor
class Actor : public GraphObject {  //derived from GraphObject class
    public:
    //constructor to initialized the object
    Actor(StudentWorld* world, int imageID, int startX, int startY, int dir = right, int depth = 0, double size = 1.0) : GraphObject(imageID, startX, startY, dir, depth, size), myWorld(world) {}
        virtual void doSomething() = 0;      //causes actor to do something
        StudentWorld* Gworld() const;        //how to access world pointer
        virtual bool isSquare() const = 0;
        virtual bool canBeHit() const = 0;      //can vortex hit it?
        virtual void hit() {return;}            //base hit function
        virtual bool isVortex() const = 0;
    private:
        //pointer to the game world
        StudentWorld* myWorld;
};

//avatar base class
class Player : public Actor {
  public:
    //constructor to initialize avatar
    Player(StudentWorld* world, int imageID, int startX, int startY, int num) : Actor(world, imageID, startX, startY), moveDir(0), ticks_to_move(0), waitingState(true), Pnum(num), p_coins(0), p_stars(0), landed(true), vortex(false), badCan(true), validDir(true){}
    //causes player to do action
    void doSomething();
    void changeDirection(int sD);          //change walk direction
    int getWalkD();                        //return walk direction
    int DiceRoll();                        //rand num 1 - 10 for dice roll
    void fixInvalid(bool checkRight, bool checkLeft, bool checkUp, bool checkDown);                     //corrects invalid direction
    int countMoves(bool checkRight, bool checkLeft, bool checkUp, bool checkDown);                       //return amt of poss moves
    void changeCoins(int amt);             //function to add/subtract coins to player
    int checkCoins() const;                 //check coin value
    void setCoins(int amt);                 //set coin amount
    bool landedP();                         //check if new player
    int Ticks2Move() const;                 //access ticks_to_move
    int checkStars() const;                 //access players stars
    void changeStars(int amt);              //change players star value
    void setStars(int amt);                 //set star amount
    void changeTicks(int tix);              //change ticks value
    bool getState() const;                   //access to waiting state
    void changeState(bool change);             //changes waiting state
    bool hasVortex();                            //checks if player has vortex
    void changeVortex(bool Vchange);            //add or remove vortex
    virtual bool isSquare() const {return false;}       //check if square
    virtual bool canBeHit() const {return false;}       //can't be hit by vortex
    void changeBadCan(bool change);                        //check baddie behavior
    bool canBad();                                      //can paused baddie act?
    void teleport();                        //teleport player
    void changeValDir(bool val);                    //changes if valid direction
    bool isVortex() const {return false;}            //not a vortex
  private:
        int moveDir;
        int ticks_to_move;
        bool waitingState;  //state of player (true = waiting to roll, false = walking)
        int Pnum;               //1 or 2
        int p_coins;
        int p_stars;
        bool landed;        //true if just landed, false if not new player
        bool badCan;
        bool vortex;
        bool validDir;      //player has valid direction
};

//PEACH class
class Peach : public Player{
public:
    //constructor for peach (player 1)
    Peach(StudentWorld* world, int startX, int startY) : Player(world, IID_PEACH, startX, startY, 1) {}
};

//YOSHI class
class Yoshi : public Player{
public:
    //constructor for yoshi (player 2)
    Yoshi(StudentWorld* world, int startX, int startY) : Player(world, IID_YOSHI, startX, startY, 2) {}
};

//base Square class
class Square : public Actor {
public:
    Square(StudentWorld* world, int imageID, int startX, int startY) : Actor(world, imageID, startX, startY, 0, 1), sq_spriteDir(0) {}
    void doSomething() = 0;
    virtual bool isSquare() const {return true;}
    virtual bool canBeHit() const {return false;}   //can't be hit by vortex
    bool isVortex() const {return false;}            //not a vortex
private:
    int sq_spriteDir;
};

//base Coin Square class
class COINSquare : public Square {
public:
    COINSquare(StudentWorld* world, int imageID, int startX, int startY, int type) : Square(world, imageID, startX, startY), CSqAlive(true){sqType = type;}
    void doSomething();
private:
    int sqType;     //blue (1) or red coin (2)
    bool CSqAlive;   //true(alive) or false(deactive)
};


//base Direction Square class
class DIRSquare : public Square {
public:
    DIRSquare(StudentWorld* world, int startX, int startY, int type) : Square(world, IID_DIR_SQUARE, startX, startY), dirType(type) {setDirection(dirType);}
    void doSomething();
private:
    int dirType;        //know which direction to drop
};

//BANK Square class
class BankS : public Square {
public:
    BankS(StudentWorld* world, int startX, int startY) : Square(world, IID_BANK_SQUARE, startX, startY) {}
    void doSomething();
private:
    
};

//Event Square class
class EventS : public Square {
public:
    EventS(StudentWorld* world, int startX, int startY) : Square(world, IID_EVENT_SQUARE, startX, startY) {}
    void doSomething();
private:
    
};

//base Dropping Square class
class DropS : public Square {
public:
    DropS(StudentWorld* world, int startX, int startY) : Square(world, IID_DROPPING_SQUARE, startX, startY) {}
    void doSomething();
private:
    
};

//Star Square class
class StarS : public Square {
public:
    StarS(StudentWorld* world, int startX, int startY) : Square(world, IID_STAR_SQUARE, startX, startY) {}
    void doSomething();
private:
    
};

//base Baddie class
class Baddie : public Actor {
public:
    Baddie(StudentWorld* world, int imageID, int startX, int startY) : Actor(world, imageID, startX, startY, right, 0, 1), PausedState(true), travelDist(0), pauseCount(180) {}
    virtual void doSomething();
    virtual bool isSquare() const {return false;}
    virtual bool canBeHit() const {return true;}    // CAN be hit by vortex
    virtual void hit();                    //baddie gets hit
    void teleport();                //teleport baddie
    bool isVortex() const {return false;}   //is vortex
    
private:
    bool PausedState;           //state of baddie (true = paused, false = walking)
    int walkingDir;             //keeps track of baddie walking dir
    int travelDist;             //baddie pixel walking distance
    int pauseCount;             //pause counter
    int squares_to_move;
    int ticks_to_move;
    virtual void doDiffStuffPause(Player* play) = 0; //allows baddies to differ while paused
    virtual int calcSquares() = 0;                  //calc squares to move
    virtual void doDiffStuffWalk() = 0;             //diff walk stuff
};

//Boo class
class Boo : public Baddie {
public:
    Boo(StudentWorld* world, int startX, int startY) : Baddie(world, IID_BOO, startX, startY) {}
    void doSomething();
    virtual void doDiffStuffPause(Player* play);
    virtual int calcSquares();                  //calc squares to move
    virtual void doDiffStuffWalk();             //boo should do nothing
private:
    
};

//Bowser class
class Bowser : public Baddie {
public:
    Bowser(StudentWorld* world, int startX, int startY) : Baddie(world, IID_BOWSER, startX, startY) {}
    void doSomething();
    virtual void doDiffStuffPause(Player* play);
    virtual int calcSquares();                  //calc squares to move
    virtual void doDiffStuffWalk();             //bowser's activities
private:
    
};

//Vortex class
class Vortex : public Actor {
public:
    Vortex(StudentWorld* world, int startX, int startY, int fd) : Actor(world, IID_VORTEX, startX, startY), active(true), firingD(fd) {}
    void doSomething();
    virtual bool isSquare() const {return false;}
    virtual bool canBeHit() const {return false;}
    bool isVortex() const {return true;}
private:
    int firingD;                    //firing direction (spec by player)
    bool active;                    //true if active, false if not
};


#endif // ACTOR_H_
