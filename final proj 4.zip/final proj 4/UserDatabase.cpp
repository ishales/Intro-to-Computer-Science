//
//  UserDatabase.cpp
//  ihproj4
//
//  Created by Isabelle Hales on 3/9/23.
//  Copyright © 2023 CS32. All rights reserved.
//

#include "UserDatabase.h"
#include "User.h"
#include "treemm.h"

#include <string>
#include <vector>
#include <iostream>
#include <fstream>
using namespace std;

//default constructor
UserDatabase::UserDatabase()
{
}

//free any dynamically allocated memory
UserDatabase::~UserDatabase(){
    //delete vector of user pointers
    vector<User*>::iterator pick = m_users.begin();
    while(pick != m_users.end()){
        User* temp = *pick;
        delete temp;
        pick = m_users.erase(pick);
    }
    m_users.clear();
}

//must load data in O (U log U) time
bool UserDatabase::load(const string& filename)
{
//  If it has not yet been called before for this UserDatabase object and it is successful in loading all of the user records in the file, it must return true. Otherwise, it must return false.
    ifstream myFile(filename);
    //file wasn't loaded properly
    if (!myFile){
        return false;
    }
    
    string line;
    while(getline(myFile, line)){
        //clear variables
        if(line == ""){
            u_name = "";
            u_email = "";
            idn = "";
            idnum = 0;
            u_mid = "";
            u_hist.clear();
            f_user = nullptr;
            continue;
        }
        u_name = line;
        getline(myFile, u_email);
        getline(myFile, idn);
        idnum = stoi(idn);
        for(int a = 0; a < idnum; a++){
            getline(myFile, u_mid);
            u_hist.push_back(u_mid);
        }
        f_user = new User(u_name, u_email, u_hist);
        m_users.push_back(f_user);
        u_tree.insert(u_email, f_user);
    }
    
    if(!m_users.empty()){
        return true;
    }
    return false;
}

//must run in O (log U) time
User* UserDatabase::get_user_from_email(const string& email) const
{
    //define iterator to correct user based on email
    TreeMultimap<string, User*>::Iterator want = u_tree.find(email);
    if(!want.is_valid()){
        return nullptr;     //iterator is invalid
    }
    return want.get_value();    //returns a pointer to correct user
}
