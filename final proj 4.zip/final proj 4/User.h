//
//  User.h
//  ihproj4
//
//  Created by Isabelle Hales on 3/9/23.
//  Copyright © 2023 CS32. All rights reserved.
//
#ifndef USER_INCLUDED
#define USER_INCLUDED

#include <string>
#include <vector>

class User
{
  public:
    User(const std::string& full_name, const std::string& email,
         const std::vector<std::string>& watch_history);
    std::string get_full_name() const;
    std::string get_email() const;
    std::vector<std::string> get_watch_history() const;

  private:
    std::string fullName;
    std::string Uemail;
    std::vector<std::string> watchHist; 
};

#endif // USER_INCLUDED
