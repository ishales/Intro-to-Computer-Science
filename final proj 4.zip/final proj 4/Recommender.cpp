//
//  Recommender.cpp
//  ihproj4
//
//  Created by Isabelle Hales on 3/9/23.
//  Copyright © 2023 CS32. All rights reserved.
//

#include "Recommender.h"
#include "UserDatabase.h"
#include "User.h"
#include "MovieDatabase.h"
#include "Movie.h"


#include <string>
#include <vector>
#include <unordered_map>
#include <map>
using namespace std;


Recommender::Recommender(const UserDatabase& user_database,
                         const MovieDatabase& movie_database)
{
    //grabs data from user and movie database
    myUsers = &user_database;
    myMovies = &movie_database;
}

vector<MovieAndRank> Recommender::recommend_movies(const string& user_email, int movie_count) const
{
    if(movie_count < 0){
        movie_count = 0;            //never deal with negative movie counts
    }
    
    User* myU = myUsers->get_user_from_email(user_email);        //define pointer to our user
    vector<string> uIDs = myU->get_watch_history();             //get watch histroy of user
    vector<Movie*> movieSeen;                       //vector of pointers to all movies user has watched
    for(int a = 0; a < uIDs.size(); a++){
        const string id = uIDs[a];
        Movie* add = myMovies->get_movie_from_id(id);    //grab pointer to movie that they've seen
        movieSeen.push_back(add);
    }
    
    unordered_map<string, int> compat;    //map for compat score
    //for each movie pointer that they've seen, determine compatability
    while(!movieSeen.empty()){
        Movie* seen = movieSeen.back();         //grabs back pointer
        movieSeen.pop_back();                   //delete extracted pointer
        vector<string> dir = seen->get_directors();     //gets directors for movie
        //for each director of movie
        while(!dir.empty()){
            string aD = dir.back();
            dir.pop_back();                     //grab and delete one director
            vector<Movie*> unseenDir = myMovies->get_movies_with_director(aD);   //all movies w dir
            //for each movie with dir
            while(!unseenDir.empty()){
                Movie* curr = unseenDir.back();
                unseenDir.pop_back();
                string currID = curr->get_id();     //get id of movie
                compat[currID] += 20;    //adds 20 to compat score
            }
        }
        //for each actor in the movie
        vector<string> act = seen->get_actors();        //gets actors of movie
        while(!act.empty()){
            string aA = act.back();
            act.pop_back();                     //grabs and deletes one pointer
            vector<Movie*> unseenAct = myMovies->get_movies_with_actor(aA);  //all movies w actor
            //for each movie with that actor
            while(!unseenAct.empty()){
                Movie* currB = unseenAct.back();
                unseenAct.pop_back();           //grab one of the movie pointers
                string currBid = currB->get_id();
                compat[currBid] += 30;          //adds 30 for compat score
            }
        }
        //for each genre of the movie
        vector<string> gen = seen->get_genres();        //gets genres of movie
        while(!gen.empty()){
            string aG = gen.back();
            gen.pop_back();                     //grans and deletes one pointer
            vector<Movie*> unseenGen = myMovies->get_movies_with_genre(aG);  //all movies w genre
            //fore each movie with that genre
            while(!unseenGen.empty()){
                Movie* currC = unseenGen.back();
                unseenGen.pop_back();           //grabs one of the movie pointers
                string currCid = currC->get_id();
                compat[currCid] += 1;           //adds 1 to compat score
            }
        }
    }
    
    //get list of candidate movies
    unordered_map<string, int>::iterator pick;
    map<int, string, greater<int>> possMovies;
    //iterate through our map to check parameters
    for(pick = compat.begin(); pick != compat.end(); pick++){
        //check movie is not already seen
        bool seenMovie = false;
        for(int ab = 0; ab < uIDs.size(); ab++){
            if(pick->first == uIDs[ab]){
                seenMovie = true;
            }
        }
        //check score is at least 1 & movie isn't seen
        if((pick->second) >= 1 && seenMovie == false){
            possMovies[pick->second] = pick->first;    //creates sorted map of score to IDs
        }
    }
    
    vector<string> finalIds;
    vector<MovieAndRank> recommends;
    //if no candidates were found
    if(possMovies.size() == 0){
        return recommends;
    }
    //If fewer compatible movies were found than the requested number, then the vector must have all movies with a compatibility score of at least 1, ordered as described above.
    map<int, string, greater<int>>::iterator choser = possMovies.begin();
    if(possMovies.size() < movie_count){
        for(int g = 0; g < possMovies.size(); g++){
            string addIA = choser->second;
            finalIds.push_back(addIA);
            choser++;
        }
    }
    else {
    //no issue loading final candidates
    //get correct final candidates
        for(int r = 0; r < movie_count; r++){
            string addIB = choser->second;
            finalIds.push_back(addIB);
            choser++;
        }
    }
    
    //if 2+ movies have same score (break tie)
    for(int m = 0; m < finalIds.size(); m++){
        if(finalIds.size() != 0 && m != finalIds.size()-1 && compat[finalIds[m]] == compat[finalIds[m+1]]){
            string id1 = finalIds[m];
            string id2 = finalIds[m+1];
            Movie* m1 = myMovies->get_movie_from_id(id1);
            Movie* m2 = myMovies->get_movie_from_id(id2);
            float r1 = m1->get_rating();
            float r2 = m2->get_rating();
            //1st var has greater rating
            if(r1 > r2){
                continue;
            } else if (r1 < r2){
                //second var has greater rating (swap values)
                string temp = id1;
                finalIds[m] = id2;
                finalIds[m+1] = temp;
                continue;
            } else {
                //same compatability & ranking (order alphabetically)
                string n1 = m1->get_title();
                string n2 = m2->get_title();
                if(n2 < n1){
                    //n2 is first alphabetically (swap them)
                    string temp = id1;
                    finalIds[m] = id2;
                    finalIds[m+1] = temp;
                }
            }
        }
    }
    
    //get final vector
    for(int y = 0; y < finalIds.size(); y++){
        string fid = finalIds[y];               //movies id
        int score = compat[fid];                //movie score
        MovieAndRank option(fid, score);        //construct movie + rank object
        recommends.push_back(option);           //add id + score to vector
    }
    
    
    return recommends;
    //return vector<MovieAndRank>();  // Replace this line with correct code.
}

