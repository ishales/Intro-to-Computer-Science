//
//  MovieDatabase.cpp
//  ihproj4
//
//  Created by Isabelle Hales on 3/9/23.
//  Copyright © 2023 CS32. All rights reserved.
//

#include "MovieDatabase.h"
#include "Movie.h"
#include "treemm.h"

#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
using namespace std;

MovieDatabase::MovieDatabase()
{
}

//free any dynamically allocated memory
MovieDatabase::~MovieDatabase(){
    //delete vector of user pointers
    
    vector<Movie*>::iterator mine = d_movies.begin();
    while(mine != d_movies.end()){
        Movie* temp = *mine;
        delete temp;
        mine = d_movies.erase(mine);
    }
    d_movies.clear();
}

//O(M log M) time
bool MovieDatabase::load(const string& filename)
{
    ifstream mFile(filename);
    //file not loaded properly
    if(!mFile){
        return false;
    }
    
    string aline;
    //read thru movie data file
    while(getline(mFile, aline)){
        //clear variables
        if(aline == ""){
            md_id = "";
            md_title = "";
            md_ry = "";
            md_rating = 0;
            md_dir.clear();
            md_act.clear();
            md_gen.clear();
            f_movie = nullptr;
            continue;
        }
        md_id = aline;  //gets movie id
        getline(mFile, md_title);   //gets movie title
        getline(mFile, md_ry);      //gets movie release yr
        getline(mFile, dirs);       //gets line of directors
        stringstream tempd(dirs);
        string curd;
        //correctly fills vector of directors
        while(getline(tempd, curd, ',')){
            md_dir.push_back(curd);
        }
        getline(mFile, acts);        //gets line of actors
        stringstream tempa(acts);    //sets input line to string stream
        string cura;
        //fills vector of actors
        while(getline(tempa, cura, ',')){
            md_act.push_back(cura);     //adds one value of actor
        }
        getline(mFile, gens);         //gets line of genres
        stringstream tempg(gens);      //sets input line to string stream
        string curg;
        //fill vector of genres
        while(getline(tempg, curg, ',')){
            md_gen.push_back(curg);
        }
        
        getline(mFile, mdr);      //gets rating for movie
        md_rating = stof(mdr);     //turns string to float

        //assign read in parameters to new movie object
        f_movie = new Movie(md_id, md_title, md_ry, md_dir, md_act, md_gen, md_rating);
        //add movie object to vector
        d_movies.push_back(f_movie);
        //add new movie to proper trees
        transform(md_id.begin(), md_id.end(), md_id.begin(), ::tolower); //case insensitive for tree
        mt_id.insert(md_id, f_movie);
        //director tree
        for(int a = 0; a < md_dir.size(); a++){
            string Din = md_dir[a];
            //make tree case insensitive
            transform(Din.begin(), Din.end(), Din.begin(), ::tolower);
            mt_dir.insert(Din, f_movie);
        }
        //actor tree
        for(int b = 0; b < md_act.size(); b++){
            string Ain = md_act[b];
            //make tree case insensitive
            transform(Ain.begin(), Ain.end(), Ain.begin(), ::tolower);
            mt_act.insert(Ain, f_movie);
        }
        //genre tree
        for(int c = 0; c < md_gen.size(); c++){
            string Gin = md_gen[c];
            //make tree case insensitive
            transform(Gin.begin(), Gin.end(), Gin.begin(), ::tolower);
            mt_gen.insert(Gin, f_movie);
        }
    }
    
    //check that movies were loaded
    if(!d_movies.empty()){
        return true;
    }

    return false;  
}

// O(log M) time for M movies
Movie* MovieDatabase::get_movie_from_id(const string& id) const
{
    string cid = id;
    transform(cid.begin(), cid.end(), cid.begin(), ::tolower);         //case insensitive for tree
    TreeMultimap<string, Movie*>::Iterator one =  mt_id.find(cid);
    if(!one.is_valid()){
        return nullptr;
    }
    return one.get_value();
}

// O(log D + md) time
vector<Movie*> MovieDatabase::get_movies_with_director(const string& director) const
{
    string d = director;
    transform(d.begin(), d.end(), d.begin(), ::tolower);         //case insensitive for tree
    vector<Movie*> dprint;
    TreeMultimap<string, Movie*>::Iterator two =  mt_dir.find(d);
    if(!two.is_valid()){
        return vector<Movie*>();        //returns equiv. null ptr ????
    }
    while(two.is_valid()){
        dprint.push_back(two.get_value());
        two.advance();
    }
    return dprint;
}

// O(log A + ma) time
vector<Movie*> MovieDatabase::get_movies_with_actor(const string& actor) const
{
    string a = actor;
    transform(a.begin(), a.end(), a.begin(), ::tolower);         //case insensitive for tree
    vector<Movie*> aprint;
    TreeMultimap<string, Movie*>::Iterator three = mt_act.find(a);
    if(!three.is_valid()){
        return vector<Movie*>();    //returns equiv. null ptr
    }
    while(three.is_valid()){
        aprint.push_back(three.get_value());
        three.advance();
    }
    return aprint;
}

//O(log G + mg) time
vector<Movie*> MovieDatabase::get_movies_with_genre(const string& genre) const
{
    string g = genre;
    transform(g.begin(), g.end(), g.begin(), ::tolower);    //case insensitive for tree
    vector<Movie*> gprint;
    TreeMultimap<string, Movie*>::Iterator four = mt_gen.find(g);
    if(!four.is_valid()){
        return vector<Movie*>();    //returns equiv. null ptr
    }
    while(four.is_valid()){
        gprint.push_back(four.get_value());
        four.advance();
    }
    return gprint; 
}
