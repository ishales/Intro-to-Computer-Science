//  treemn.h
//  ihproj4
//
//  Created by Isabelle Hales on 3/13/23.
//  Copyright © 2023 CS32. All rights reserved.
//

#ifndef TREEMULTIMAP_INCLUDED
#define TREEMULTIMAP_INCLUDED

template <typename KeyType, typename ValueType>
class TreeMultimap
{
  public:
    class Iterator
    {
      public:
        //default constructor
        Iterator()
        {
            //set iterator to invalid
            ival = nullptr;
            currPos = 0;
        }
        
        //main constructor
        Iterator(std::vector<ValueType> &val)
        {
            //reference correct vector
            ival = &val;
            //set iterator to reference first value of vector
            currPos = 0;
        }

        //gets value for iterator
        ValueType& get_value() const
        {
            //gets value that iterator points to in vector
            return (*ival)[currPos];
        }

        //gets validity of iterator
        bool is_valid() const
        {
            //true if iterator is valid, false if iterator is invalid
            if(currPos < ival->size()){
                return true;
            } else {
                return false;
            }
        }

        //advances iterator
        void advance()
        {
            currPos++;
        }

      private:
        int currPos;
        std::vector<ValueType>* ival;
    };

    TreeMultimap()
    {
        //root of tree is set to null
        root = nullptr;
    }

    ~TreeMultimap()
    {
        //calls recursive function to free all pointers in tree
        freeTree(root);
    }

    void insert(const KeyType& key, const ValueType& value)
    {
        //if tree is empty
        if(root == nullptr){
            root = new Node(key);
            root->val_t.push_back(value);
            return;
        }
        //set pointer to root of tree
        Node* curr = root;
        for(;;){
            //value we're trying to insert already exists
            if(key == curr->key_t){
                //insert another value
                curr->val_t.push_back(value);
                return;
            }
            // key is less than curr key (go left)
            else if(key < curr->key_t){
                if(curr->left != nullptr){
                    curr = curr->left;
                } else {
                    //if we hit end, insert new Node with value
                    curr->left = new Node(key);
                    curr->left->val_t.push_back(value);
                    return;
                }
            }
            //key is greater than curr key (go right)
            else if(key > curr->key_t){
                if(curr->right != nullptr){
                    curr = curr->right;
                } else {
                    //if we hit end, insert new Node
                    curr->right = new Node(key);
                    curr->right->val_t.push_back(value);
                    return;
                }
            }
        }
    }

    Iterator find(const KeyType& key) const
    {
        Node* temp = root;
        while(temp != nullptr){
            if(key == temp->key_t){
                return Iterator(temp->val_t);      //returns current node's value vector
            } else if(key < temp->key_t){
            //searches left of tree if key is less (points to left child)
                temp = temp->left;
            } else if(key > temp->key_t){
            //searches right of tree if key is greater (points to right child)
                temp = temp->right;
            }
        }
        return Iterator();      //returns invalid iterator
    }
    

  private:
    //struct for node of trees
    struct Node {
        Node(const KeyType& key) : key_t(key), right(nullptr), left(nullptr) {}
        KeyType key_t;
        std::vector<ValueType> val_t;
        Node* right;
        Node* left;
    };
    Node* root;
    
    //function to free the tree
    void freeTree(Node* temp){
        if(temp == nullptr)
            return;
        //recursively delete the nodes within the tree
        freeTree(temp->left);
        freeTree(temp->right);
        delete temp;
    }
};

#endif // TREEMULTIMAP_INCLUDED
