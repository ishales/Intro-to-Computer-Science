//
//  Movie.cpp
//  ihproj4
//
//  Created by Isabelle Hales on 3/9/23.
//  Copyright © 2023 CS32. All rights reserved.
//

#include "Movie.h"

#include <string>
#include <vector>
using namespace std;

Movie::Movie(const string& id, const string& title, const string& release_year,
             const vector<string>& directors, const vector<string>& actors,
             const vector<string>& genres, float rating)
{
    m_id = id;
    m_title = title;
    m_releaseYr = release_year;
    m_rating = rating;
    m_directors = directors;
    m_actors = actors;
    m_genres = genres;
}

//gets move ID
string Movie::get_id() const
{
    return m_id;
}

//gets movie title
string Movie::get_title() const
{
    return m_title;
}

//gets release yr
string Movie::get_release_year() const
{
    return m_releaseYr; 
}

//gets movie rating
float Movie::get_rating() const
{
    return m_rating;
}

//gets movie directors
vector<string> Movie::get_directors() const
{
    return m_directors;
}

//gets movie actors
vector<string> Movie::get_actors() const
{
    return m_actors;
}

//gets movie genres
vector<string> Movie::get_genres() const
{
    return m_genres; 
}

