//
//  UserDatabase.hpp
//  ihproj4
//
//  Created by Isabelle Hales on 3/9/23.
//  Copyright © 2023 CS32. All rights reserved.
//


#ifndef USERDATABASE_INCLUDED
#define USERDATABASE_INCLUDED

#include <string>
#include <vector>
#include "treemm.h"

class User;

class UserDatabase
{
  public:
    UserDatabase();
    ~UserDatabase();
    bool load(const std::string& filename);
    User* get_user_from_email(const std::string& email) const;

  private:
    std::string u_name;
    std::string u_email;
    std::string idn;
    int idnum;
    std::string u_mid;
    std::vector<std::string> u_hist;
    User* f_user;
    std::vector<User*> m_users;
    TreeMultimap<std::string, User*> u_tree;
};

#endif // USERDATABASE_INCLUDED
