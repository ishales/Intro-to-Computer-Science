//
//  MovieDatabase.h
//  ihproj4
//
//  Created by Isabelle Hales on 3/9/23.
//  Copyright © 2023 CS32. All rights reserved.
//

#ifndef MOVIEDATABASE_INCLUDED
#define MOVIEDATABASE_INCLUDED

#include <string>
#include <vector>
#include "treemm.h"

class Movie;

class MovieDatabase
{
  public:
    MovieDatabase();
    ~MovieDatabase();
    bool load(const std::string& filename);
    Movie* get_movie_from_id(const std::string& id) const;
    std::vector<Movie*> get_movies_with_director(const std::string& director) const;
    std::vector<Movie*> get_movies_with_actor(const std::string& actor) const;
    std::vector<Movie*> get_movies_with_genre(const std::string& genre) const;

  private:
    std::string md_id;
    std::string md_title;
    std::string md_ry;
    std::string dirs;
    std::string acts;
    std::string gens;
    std::string mdr;
    float md_rating;
    std::vector<std::string> md_dir;
    std::vector<std::string> md_act;
    std::vector<std::string> md_gen;
    Movie* f_movie;
    std::vector<Movie*> d_movies;
    TreeMultimap<std::string, Movie*> mt_id;
    TreeMultimap<std::string, Movie*> mt_dir;
    TreeMultimap<std::string, Movie*> mt_act;
    TreeMultimap<std::string, Movie*> mt_gen;
    
};

#endif // MOVIEDATABASE_INCLUDED
